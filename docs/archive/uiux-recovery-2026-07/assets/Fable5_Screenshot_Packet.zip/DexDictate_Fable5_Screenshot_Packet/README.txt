DexDictate screenshot packet extracted from BetterCapture_2026-07-09-02.44.57.mov

Method: generous scene-change extraction across the full screen recording.
Count: 59 screenshots plus a contact sheet and manifest.

Contents:
- screens/: extracted PNG screenshots named by order and approximate timestamp
- contact_sheet.png: overview grid of all extracted screenshots
- manifest.csv: filename-to-timestamp index

Note: some screenshots may be transitional or near-duplicate; they were intentionally kept to be generous so Fable has fuller visual coverage.
